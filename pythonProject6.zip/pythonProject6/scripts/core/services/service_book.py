from fastapi import APIRouter
from schemas.models import Email, Book
from scripts.constants.app_constants import Book_end
from scripts.core.handlers.Book_handler import welcome, read_book, create_book, update_book, delete_book, pipeline_agg
from scripts.core.handlers.email_handler import send_email

app = APIRouter()


@app.get("/")
def fun():
    return welcome()


@app.get(Book_end.get_books)
def fun():
    return read_book()


@app.post(Book_end.create_books)
def fun(book: Book):
    return create_book(book)


@app.put(Book_end.update_books)
def fun(name: str, book: Book):
    return update_book(name, book)


@app.delete(Book_end.delete_books)
def fun(name: str):
    return delete_book(name)


@app.post(Book_end.send_mail)
def fun(email: Email):
    total_amount = pipeline_agg()
    return send_email(str(total_amount), email)


@app.get(Book_end.pipeline_arg)
def fun():
    return pipeline_agg()
