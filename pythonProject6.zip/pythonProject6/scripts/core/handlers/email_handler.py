from fastapi import FastAPI
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from schemas.models import Email
from scripts.constants.emailcong import email_obj
# from scripts.core.DB.MongoDB import inventory
from utility.mong_utility import inventory
from scripts.core.handlers import Book_handler
# app = FastAPI()


def send_email(body: str, email: Email):
    # Set up the email details
    sender_email = email_obj.sender_email
    sender_password = email_obj.sender_password
    receiver_email = email.rec_email

    # Create a multipart message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = email.subject

    # Add the body to the email
    message.attach(MIMEText(body, "plain"))

    count_books = Book_handler.read_book()
    str_count = str(count_books)

    #total_books = inventory.object_read_book()
    message.attach(MIMEText("Total number of books:\n" + str_count ))


    try:
        # Create a secure connection to the SMTP server
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()

        # Login to the sender's email account
        server.login(sender_email, sender_password)

        # Send the email
        server.send_message(message)

        # Close the connection
        server.quit()

        return {"message": "Email sent successfully"}
    except Exception as e:
        return {"message": str(e)}
