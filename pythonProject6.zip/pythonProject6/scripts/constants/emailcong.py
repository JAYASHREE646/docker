class Email_Constants:
    sender_email = "jayashree12277@gmail.com"
    sender_password = "utysnhbbmhunovtr"


email_obj = Email_Constants()
